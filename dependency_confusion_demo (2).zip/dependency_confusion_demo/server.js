// server.js
const express = require("express");
const { spawn } = require("child_process");
const path = require("path");
const app = express();
const cors = require("cors");

app.use(express.static(path.join(__dirname, 'victim-app/ui')));

app.use(cors());

app.get("/simulate-install", (req, res) => {
  res.setHeader("Content-Type", "text/plain");

  try {

    const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
    const install = spawn("npm", ["install", "--foreground-scripts","--registry", "http://localhost:4873"], {
      cwd: path.join(__dirname, "victim-app"),
        shell: true, 
    });

    install.stdout.on("data", (data) => {
      res.write(data.toString());
    });

    install.stderr.on("data", (data) => {
      res.write(`ERROR: ${data.toString()}`);
    });

    install.on("error", (err) => {
      res.write(`\n❌ Failed to run npm install: ${err.message}\n`);
      res.end();
    });

    install.on("close", (code) => {
      if (code === 0) {
        res.write(`\n✅ npm install completed successfully (exit code ${code})`);
      } else {
        res.write(`\n❌ npm install failed (exit code ${code})`);
      }
      res.end();
    });
  } catch (err) {
    res.status(500).send(`❌ Internal server error: ${err.message}`);
  }
});


app.get("/simulate-install-scoped", (req, res) => {

  try {
  const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";

  const install = spawn(npmCmd, ["install","--foreground-scripts"], {
    cwd: path.join(__dirname, "victim-app-scoped"),
    shell: true,
  });

  install.stdout.on("data", (data) => res.write(data.toString()));
  install.stderr.on("data", (data) => res.write(`ERROR: ${data.toString()}`));
  install.on("close", (code) => {
    res.write(`\nExit code: ${code}`);
    res.end();
  });

  } catch (err) {
    res.status(500).send(`❌ Internal server error: ${err.message}`);
  }
});


app.listen(3001, () => console.log("Server running at http://localhost:3001"));