# Break and Fix It: Dependency Confusion Demo

## Step 1: Break It
- Run `npm install` in this directory.
- Observe the malicious message from the fake `internal-lib`.

## Step 2: Fix It
- Change your `.npmrc` to:
  @your-org:registry=http://localhost:4873/
  registry=http://invalid.local/
- Change dependency to `@your-org/internal-lib` with version `1.0.0`
- Run `npm install` again.
- Confirm no malicious output appears.

---